let a = function(){

}
let b = [1,2,3];
console.log(typeof(b));


/*sdad */
//sda

